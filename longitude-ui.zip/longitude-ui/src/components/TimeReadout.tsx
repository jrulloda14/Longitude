/**
 * TimeReadout — the digital twin of the dial and its accessible alternative.
 * Shows the selected time large; it IS an input: click or Tab in, type
 * "14:30", "2:30p", "noon", press Enter. Resolves DST gaps/overlaps and says so.
 */
import { ChevronLeft, ChevronRight, RotateCcw } from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { parseTimeOfDay } from '../lib/parse';
import {
  Instant, formatOffset, formatShortDate, formatTime, formatTimeString, offsetMinutes, relativeDay, relativeSpan,
  resolveWall, wallTime, zoneAbbreviation, WallResolution,
} from '../lib/time';
import { Button, IconButton, Tip, cx } from '../primitives';
import { DstNotice } from './DstNotice';

export interface TimeReadoutProps {
  value: Instant;
  now: Instant;
  zone: string;
  placeLabel: string;
  live: boolean;
  hour12: boolean;
  onChange(next: Instant, source: 'input' | 'key'): void;
  onReset(): void;
  compact?: boolean;
}

export function TimeReadout({ value, now, zone, placeLabel, live, hour12, onChange, onReset, compact }: TimeReadoutProps) {
  const { time, period } = formatTime(zone, value, { hour12 });
  const [draft, setDraft] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [resolution, setResolution] = useState<WallResolution | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // A new value from elsewhere clears any stale DST note.
  const lastCommitted = useRef<Instant | null>(null);
  useEffect(() => {
    if (lastCommitted.current !== null && lastCommitted.current !== value) setResolution(null);
  }, [value]);

  const commit = () => {
    if (draft === null) return;
    const r = parseTimeOfDay(draft, hour12);
    if (!r.ok) { setError(r.error); return; }
    const w = wallTime(zone, value);
    const res = resolveWall(zone, w.year, w.month, w.day, Math.floor(r.minutes / 60), r.minutes % 60);
    setError(null);
    setDraft(null);
    setResolution(res.kind === 'ok' ? null : res);
    lastCommitted.current = res.instant;
    onChange(res.instant, 'input');
    inputRef.current?.blur();
  };

  const stepDay = (d: 1 | -1) => onChange(value + d * 86_400_000, 'key');
  const abbr = zoneAbbreviation(zone, value);
  const offs = formatOffset(offsetMinutes(zone, value));

  return (
    <div className={cx('flex flex-col items-center', compact ? 'gap-1' : 'gap-1.5')}>
      <div className="flex items-baseline gap-1.5">
        <label className="sr-only" htmlFor="lg-time-input">Selected time in {placeLabel}</label>
        <input
          id="lg-time-input"
          ref={inputRef}
          className={cx(
            'lg-no-ring tnum w-[5.2ch] rounded-md border border-transparent bg-transparent text-center font-medium tracking-[-0.02em] text-ink outline-none transition-colors',
            compact ? 'text-[28px] leading-[32px]' : 'text-readout',
            'hover:border-line focus:border-line-strong focus:bg-field',
            error && '!border-danger',
          )}
          style={{ width: `${Math.max(4.2, (draft ?? time).length + 0.2)}ch` }}
          value={draft ?? time}
          aria-invalid={!!error}
          aria-describedby={error ? 'lg-time-err' : undefined}
          onFocus={(e) => { setDraft(time + (period ? ' ' + period.toLowerCase() : '')); requestAnimationFrame(() => e.target.select()); }}
          onChange={(e) => { setDraft(e.target.value); setError(null); }}
          onBlur={() => { if (!error) setDraft(null); }}
          onKeyDown={(e) => {
            if (e.key === 'Enter') commit();
            if (e.key === 'Escape') { setDraft(null); setError(null); inputRef.current?.blur(); }
          }}
          spellCheck={false}
          autoComplete="off"
        />
        {period && draft === null && <span className="text-label font-semibold tracking-[0.06em] text-ink-muted">{period}</span>}
      </div>

      {error ? (
        <p id="lg-time-err" role="alert" className="text-caption text-danger">{error}</p>
      ) : (
        <div className="flex items-center gap-0.5 text-label text-ink-muted">
          <IconButton label="Previous day" shortcut="[" className="!h-6 !w-6" onClick={() => stepDay(-1)}><ChevronLeft size={14} /></IconButton>
          <span className="tnum min-w-[120px] text-center">
            <span className={cx(relativeDay(zone, value, now) !== 'Today' && 'text-ink')}>{relativeDay(zone, value, now)}</span>
            <span className="text-ink-faint"> · </span>
            {formatShortDate(zone, value)}
          </span>
          <IconButton label="Next day" shortcut="]" className="!h-6 !w-6" onClick={() => stepDay(1)}><ChevronRight size={14} /></IconButton>
        </div>
      )}

      {!compact && (
        <div className="flex items-center gap-2 text-caption text-ink-faint">
          <Tip label={`${zone} · ${offs}`}>
            <span tabIndex={0} className="rounded-sm">{placeLabel} · {abbr}{abbr.startsWith('UTC') ? '' : ` ${offs}`}</span>
          </Tip>
          <span aria-hidden>·</span>
          {live ? (
            <span className="inline-flex items-center gap-1 text-ink-muted"><span className="lg-pulse h-1.5 w-1.5 rounded-full bg-work" /> Live</span>
          ) : (
            <span className="tnum">{relativeSpan(value, now)}</span>
          )}
        </div>
      )}

      <div className="h-7">
        {!live && (
          <Button size="sm" variant="secondary" icon={<RotateCcw size={12} />} onClick={onReset} title="Back to now (Home, or double-click the dial)">
            Now · {formatTimeString(zone, now, { hour12 })}
          </Button>
        )}
      </div>

      {resolution && resolution.kind === 'ambiguous' && (
        <DstNotice tone="info">
          {formatTimeString(zone, resolution.alternatives[0], { hour12 })} happens twice in {placeLabel} that night (clocks go back). Using the first, {zoneAbbreviation(zone, resolution.alternatives[0])}.{' '}
          <button className="text-ink underline decoration-line-strong underline-offset-2 hover:decoration-ink" onClick={() => { const alt = resolution.alternatives[1]; lastCommitted.current = alt; onChange(alt, 'input'); setResolution(null); }}>
            Use the second ({zoneAbbreviation(zone, resolution.alternatives[1])})
          </button>
        </DstNotice>
      )}
      {resolution && resolution.kind === 'nonexistent' && (
        <DstNotice tone="info">
          That time doesn't exist in {placeLabel} — clocks skip ahead {resolution.gapMinutes} min. Moved to {formatTimeString(zone, resolution.instant, { hour12 })}.
        </DstNotice>
      )}
    </div>
  );
}
