/**
 * Timezone engine — pure functions, no React, no platform APIs.
 *
 * Every calculation goes through the platform's IANA tz database via
 * Intl.DateTimeFormat. Nothing here stores or hardcodes a UTC offset:
 * offsets are always derived for a specific instant, so DST and historical
 * rule changes are honoured automatically.
 *
 * Instants are plain epoch milliseconds (number). "Wall" values are the
 * civil date/time a person in that zone would read off their wall clock.
 */

export type Instant = number;

export interface WallTime {
  year: number;
  month: number; // 1–12
  day: number; // 1–31
  hour: number; // 0–23
  minute: number;
  second: number;
  weekday: number; // 0 = Sunday
}

const MIN = 60_000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

const partsCache = new Map<string, Intl.DateTimeFormat>();
function partsFormatter(zone: string): Intl.DateTimeFormat {
  let f = partsCache.get(zone);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: zone,
      hourCycle: 'h23',
      year: 'numeric',
      month: 'numeric',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric',
      weekday: 'short',
    });
    partsCache.set(zone, f);
  }
  return f;
}

const WEEKDAYS: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

/** Is this string a zone the runtime's tz database knows? */
export function isValidZone(zone: string): boolean {
  try {
    partsFormatter(zone);
    return true;
  } catch {
    return false;
  }
}

/** The zone the OS reports. Production: prefer the Tauri side if it disagrees. */
export function systemZone(): string {
  return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
}

export function wallTime(zone: string, at: Instant): WallTime {
  const out: Partial<WallTime> = {};
  for (const p of partsFormatter(zone).formatToParts(new Date(at))) {
    switch (p.type) {
      case 'year': out.year = +p.value; break;
      case 'month': out.month = +p.value; break;
      case 'day': out.day = +p.value; break;
      case 'hour': out.hour = +p.value % 24; break;
      case 'minute': out.minute = +p.value; break;
      case 'second': out.second = +p.value; break;
      case 'weekday': out.weekday = WEEKDAYS[p.value] ?? 0; break;
    }
  }
  return out as WallTime;
}

/** UTC offset in minutes for `zone` at instant `at` (e.g. +330 for Kolkata). */
export function offsetMinutes(zone: string, at: Instant): number {
  const w = wallTime(zone, at);
  const asUtc = Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute, w.second);
  const truncated = Math.floor(at / 1000) * 1000;
  return Math.round((asUtc - truncated) / MIN);
}

/** Minutes since local midnight (0–1439). */
export function minuteOfDay(zone: string, at: Instant): number {
  const w = wallTime(zone, at);
  return w.hour * 60 + w.minute;
}

/** Days since epoch of the local civil date — compare two zones' dates. */
export function dayNumber(zone: string, at: Instant): number {
  const w = wallTime(zone, at);
  return Math.floor(Date.UTC(w.year, w.month - 1, w.day) / DAY);
}

/** Local calendar-day difference of `zone` relative to `refZone` at `at` (−1, 0, +1). */
export function dayShift(zone: string, refZone: string, at: Instant): number {
  return dayNumber(zone, at) - dayNumber(refZone, at);
}

export type WallResolution =
  | { kind: 'ok'; instant: Instant }
  | { kind: 'ambiguous'; instant: Instant; alternatives: [Instant, Instant] }
  | { kind: 'nonexistent'; instant: Instant; gapMinutes: number };

/**
 * Convert a wall time in `zone` to an instant. Detects the two DST edge cases:
 *  - ambiguous: the wall time happens twice (clocks fall back). Returns the
 *    earlier instant and both alternatives.
 *  - nonexistent: the wall time is skipped (clocks spring forward). Returns the
 *    instant after the gap (what most calendar apps do) and the gap length.
 */
export function resolveWall(
  zone: string,
  year: number,
  month: number,
  day: number,
  hour: number,
  minute: number,
): WallResolution {
  const guess = Date.UTC(year, month - 1, day, hour, minute);
  const offsets = new Set<number>([
    offsetMinutes(zone, guess - DAY),
    offsetMinutes(zone, guess),
    offsetMinutes(zone, guess + DAY),
  ]);
  const hits: Instant[] = [];
  for (const off of offsets) {
    const t = guess - off * MIN;
    const w = wallTime(zone, t);
    if (w.year === year && w.month === month && w.day === day && w.hour === hour && w.minute === minute) {
      if (!hits.includes(t)) hits.push(t);
    }
  }
  hits.sort((a, b) => a - b);
  if (hits.length === 1) return { kind: 'ok', instant: hits[0] };
  if (hits.length >= 2) return { kind: 'ambiguous', instant: hits[0], alternatives: [hits[0], hits[1]] };
  // Gap: use the offset in force *before* the transition, which lands after it.
  const before = offsetMinutes(zone, guess - DAY);
  const after = offsetMinutes(zone, guess + DAY);
  return { kind: 'nonexistent', instant: guess - before * MIN, gapMinutes: Math.abs(after - before) };
}

/** Instant of local midnight starting the civil day that contains `at` in `zone`. */
export function startOfLocalDay(zone: string, at: Instant): Instant {
  const w = wallTime(zone, at);
  const r = resolveWall(zone, w.year, w.month, w.day, 0, 0);
  return r.instant;
}

/** Add whole civil days in `zone`, keeping wall time (DST-safe). */
export function addLocalDays(zone: string, at: Instant, days: number): Instant {
  const w = wallTime(zone, at);
  const d = new Date(Date.UTC(w.year, w.month - 1, w.day + days));
  return resolveWall(zone, d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate(), w.hour, w.minute).instant;
}

export interface OffsetTransition {
  at: Instant; // first instant with the new offset
  from: number; // minutes
  to: number;
}

const transitionCache = new Map<string, OffsetTransition | null>();

/**
 * Next UTC-offset change for `zone` after `from`, within `horizonDays`.
 * Daily sampling + binary search to the minute. Results are cached per zone/day.
 */
export function nextTransition(zone: string, from: Instant, horizonDays = 45): OffsetTransition | null {
  from = Math.floor(from / MIN) * MIN;
  const key = `${zone}|${Math.floor(from / HOUR)}|${horizonDays}`;
  if (transitionCache.has(key)) return transitionCache.get(key)!;
  let prev = offsetMinutes(zone, from);
  let result: OffsetTransition | null = null;
  for (let i = 1; i <= horizonDays; i++) {
    const t = from + i * DAY;
    const off = offsetMinutes(zone, t);
    if (off !== prev) {
      let lo = t - DAY;
      let hi = t;
      while (hi - lo > MIN) {
        const mid = lo + Math.floor((hi - lo) / 2 / MIN) * MIN;
        if (mid === lo) break;
        if (offsetMinutes(zone, mid) === prev) lo = mid;
        else hi = mid;
      }
      result = { at: hi, from: prev, to: off };
      break;
    }
    prev = off;
  }
  transitionCache.set(key, result);
  return result;
}

// ── Formatting ──────────────────────────────────────────────────────────────

export function formatOffset(mins: number): string {
  if (mins === 0) return 'UTC';
  const sign = mins > 0 ? '+' : '−';
  const a = Math.abs(mins);
  const h = Math.floor(a / 60);
  const m = a % 60;
  return `UTC${sign}${h}${m ? ':' + String(m).padStart(2, '0') : ''}`;
}

/** "+12h", "−5h 30m", "Same time". Input in minutes. */
export function formatDiff(mins: number): string {
  if (mins === 0) return 'Same time';
  const sign = mins > 0 ? '+' : '−';
  const a = Math.abs(mins);
  const h = Math.floor(a / 60);
  const m = a % 60;
  return `${sign}${h ? h + 'h' : ''}${h && m ? ' ' : ''}${m ? m + 'm' : ''}`;
}

const abbrCache = new Map<string, string>();
/** Short alphabetic abbreviation when the runtime has one (EDT, BST, JST); else UTC±h. */
export function zoneAbbreviation(zone: string, at: Instant): string {
  const key = `${zone}|${Math.floor(at / (15 * MIN))}`;
  const hit = abbrCache.get(key);
  if (hit) return hit;
  let result = '';
  for (const locale of ['en-US', 'en-GB', 'en-AU', 'en-IN']) {
    const name = new Intl.DateTimeFormat(locale, { timeZone: zone, timeZoneName: 'short' })
      .formatToParts(new Date(at))
      .find((p) => p.type === 'timeZoneName')?.value;
    if (name && /^[A-Z]{2,5}$/.test(name)) {
      result = name;
      break;
    }
  }
  if (!result) result = formatOffset(offsetMinutes(zone, at));
  abbrCache.set(key, result);
  return result;
}

export interface TimeFormat {
  hour12: boolean;
}

export function formatTime(zone: string, at: Instant, fmt: TimeFormat): { time: string; period: string } {
  const w = wallTime(zone, at);
  const mm = String(w.minute).padStart(2, '0');
  if (!fmt.hour12) return { time: `${String(w.hour).padStart(2, '0')}:${mm}`, period: '' };
  const h = w.hour % 12 || 12;
  return { time: `${h}:${mm}`, period: w.hour < 12 ? 'AM' : 'PM' };
}

export function formatTimeString(zone: string, at: Instant, fmt: TimeFormat): string {
  const { time, period } = formatTime(zone, at, fmt);
  return period ? `${time} ${period}` : time;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MONTHS_LONG = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const DAYS_LONG = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/** "Mon 19 Oct" */
export function formatShortDate(zone: string, at: Instant): string {
  const w = wallTime(zone, at);
  return `${DAYS[w.weekday]} ${w.day} ${MONTHS[w.month - 1]}`;
}

/** "Tuesday, October 20, 2026" */
export function formatLongDate(zone: string, at: Instant): string {
  const w = wallTime(zone, at);
  return `${DAYS_LONG[w.weekday]}, ${MONTHS_LONG[w.month - 1]} ${w.day}, ${w.year}`;
}

export function formatDateTimeShort(zone: string, at: Instant, fmt: TimeFormat): string {
  return `${formatShortDate(zone, at)}, ${formatTimeString(zone, at, fmt)}`;
}

/** Relative-day word for `at` vs `now` in `zone`: Today / Tomorrow / Yesterday / +3 days. */
export function relativeDay(zone: string, at: Instant, now: Instant): string {
  const d = dayNumber(zone, at) - dayNumber(zone, now);
  if (d === 0) return 'Today';
  if (d === 1) return 'Tomorrow';
  if (d === -1) return 'Yesterday';
  return d > 0 ? `In ${d} days` : `${-d} days ago`;
}

/** "in 3h 25m" / "2h ago" / "now" */
export function relativeSpan(at: Instant, now: Instant): string {
  const mins = Math.round((at - now) / MIN);
  if (Math.abs(mins) < 1) return 'now';
  const a = Math.abs(mins);
  const d = Math.floor(a / 1440);
  const h = Math.floor((a % 1440) / 60);
  const m = a % 60;
  const s = [d ? `${d}d` : '', h ? `${h}h` : '', m && !d ? `${m}m` : ''].filter(Boolean).join(' ');
  return mins > 0 ? `in ${s}` : `${s} ago`;
}

export const MS = { MIN, HOUR, DAY };
